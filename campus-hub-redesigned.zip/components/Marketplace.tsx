'use client';

import { useState, useEffect } from 'react';
import { collection, query, orderBy, onSnapshot, doc, deleteDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useAuthStore } from '@/lib/store';
import Image from 'next/image';
import { Trash2, Sparkles, TrendingUp } from 'lucide-react';

const CATEGORIES = ['All', 'Housing', 'Events', 'Electronics', 'Clothing', 'Services', 'Other'];

const renderWithLinks = (text: string) => {
  if (!text) return null;
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const parts = text.split(urlRegex);
  return parts.map((part, i) => {
    if (part.match(urlRegex)) {
      return (
        <a key={i} href={part} target="_blank" rel="noopener noreferrer" className="underline underline-offset-2" style={{ color: 'var(--color-accent)' }} onClick={(e) => e.stopPropagation()}>
          {part}
        </a>
      );
    }
    return part;
  });
};

export function Marketplace() {
  const { user, profile } = useAuthStore();
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState('All');
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const prods = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setProducts(prods);
      setLoading(false);
    }, (error) => { console.error("Error fetching products:", error); setLoading(false); });
    return () => unsubscribe();
  }, []);

  const filteredProducts = activeCategory === 'All' ? products : products.filter(p => p.category === activeCategory);

  const confirmDelete = async () => {
    if (!deleteId) return;
    try { await deleteDoc(doc(db, 'products', deleteId)); setDeleteId(null); }
    catch (error) { console.error("Error deleting:", error); }
  };

  return (
    <div className="min-h-screen pb-32">
      {/* Header */}
      <header className="px-5 pt-8 pb-4 max-w-2xl mx-auto">
        <div className="flex justify-between items-start mb-6">
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-[color:var(--color-muted-foreground)] mb-1.5">
              Welcome back
            </p>
            <h1 className="font-display text-3xl leading-none text-[color:var(--color-foreground)]">
              {profile?.name?.split(' ')[0] || 'Hello'}.
            </h1>
          </div>
          <div className="size-11 rounded-full overflow-hidden flex items-center justify-center" style={{ background: 'var(--color-muted)' }}>
            {profile?.photoUrl ? (
              <Image src={profile.photoUrl} alt="Profile" width={44} height={44} className="object-cover w-full h-full" />
            ) : (
              <span className="font-semibold text-[color:var(--color-primary)]">{profile?.name?.charAt(0) || 'U'}</span>
            )}
          </div>
        </div>

        {/* Hero card */}
        <div className="rounded-[1.5rem] p-5 mb-6 relative overflow-hidden" style={{ background: 'linear-gradient(135deg, var(--color-primary) 0%, #2a3a66 100%)' }}>
          <div className="absolute -right-8 -top-8 size-32 rounded-full opacity-20" style={{ background: 'var(--color-accent)' }} />
          <div className="absolute -right-16 -bottom-16 size-40 rounded-full opacity-10" style={{ background: 'var(--color-accent)' }} />
          <div className="relative">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-medium uppercase tracking-wider mb-3" style={{ background: 'rgba(255,255,255,0.15)', color: 'white' }}>
              <Sparkles className="w-3 h-3" /> What's new
            </span>
            <h2 className="font-display text-white text-2xl leading-tight mb-1">Discover what your campus is selling.</h2>
            <p className="text-white/70 text-sm">Fresh listings from student vendors, posted in real-time.</p>
          </div>
        </div>

        {/* Categories */}
        <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-5 px-5">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all ${
                activeCategory === cat
                  ? 'text-white shadow-md'
                  : 'bg-white text-[color:var(--color-foreground)] border'
              }`}
              style={activeCategory === cat ? { background: 'var(--color-primary)' } : { borderColor: 'var(--color-border)' }}
            >
              {cat}
            </button>
          ))}
        </div>
      </header>

      {/* Feed */}
      <main className="px-5 max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-3">
          <h3 className="section-title text-lg">{activeCategory === 'All' ? 'All listings' : activeCategory}</h3>
          <span className="text-xs text-[color:var(--color-muted-foreground)] flex items-center gap-1">
            <TrendingUp className="w-3 h-3" /> {filteredProducts.length} item{filteredProducts.length !== 1 ? 's' : ''}
          </span>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 gap-4">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="card p-3 animate-pulse">
                <div className="w-full aspect-square bg-[color:var(--color-muted)] rounded-xl mb-3" />
                <div className="h-4 bg-[color:var(--color-muted)] rounded w-3/4 mb-2" />
                <div className="h-4 bg-[color:var(--color-muted)] rounded w-1/2" />
              </div>
            ))}
          </div>
        ) : filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 gap-4">
            {filteredProducts.map(product => {
              const mediaUrl = product.mediaUrls?.[0] || product.imageUrl;
              const isVideo = mediaUrl?.match(/\.(mp4|webm|mov|m4v)(\?.*)?$/i);
              return (
                <article key={product.id} className="card p-3 flex flex-col group">
                  <div className="relative w-full aspect-square rounded-xl overflow-hidden mb-3" style={{ background: 'var(--color-muted)' }}>
                    {isVideo ? (
                      <video src={mediaUrl} className="object-cover w-full h-full" muted loop playsInline autoPlay />
                    ) : mediaUrl ? (
                      <Image src={mediaUrl} alt={product.name} fill className="object-cover transition-transform group-hover:scale-[1.03]" sizes="(max-width: 768px) 50vw, 33vw" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-xs text-[color:var(--color-muted-foreground)]">No media</div>
                    )}
                    {product.category && (
                      <span className="absolute top-2 left-2 text-[10px] uppercase tracking-wider font-semibold px-2 py-1 rounded-full bg-white/95 text-[color:var(--color-foreground)] shadow-sm">{product.category}</span>
                    )}
                    {user?.uid === product.vendorId && (
                      <button onClick={(e) => { e.stopPropagation(); setDeleteId(product.id); }} className="absolute top-2 right-2 p-2 bg-white/95 rounded-full hover:scale-105 shadow-sm" style={{ color: 'var(--color-danger)' }}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <h3 className="font-semibold text-[color:var(--color-foreground)] text-sm line-clamp-1">{product.name}</h3>
                  <p className="text-[11px] text-[color:var(--color-muted-foreground)] line-clamp-1 mt-0.5">by {product.vendorName}</p>
                  {product.description && (
                    <p className="text-xs text-[color:var(--color-muted-foreground)] mt-1.5 line-clamp-2 break-words">{renderWithLinks(product.description)}</p>
                  )}
                  <div className="mt-3 pt-3 border-t flex items-baseline justify-between" style={{ borderColor: 'var(--color-border)' }}>
                    <span className="font-display text-lg text-[color:var(--color-foreground)]">${product.price?.toFixed(2)}</span>
                    <span className="text-[10px] uppercase tracking-wider font-medium" style={{ color: 'var(--color-accent)' }}>View</span>
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="card p-10 text-center">
            <p className="font-display text-xl mb-1">Nothing here yet</p>
            <p className="text-sm text-[color:var(--color-muted-foreground)]">No products in this category. Check back soon.</p>
          </div>
        )}
      </main>

      {/* Delete Modal */}
      {deleteId && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
          <div className="card p-6 max-w-sm w-full" style={{ boxShadow: 'var(--shadow-elevated)' }}>
            <h3 className="font-display text-2xl mb-1">Delete listing?</h3>
            <p className="text-sm text-[color:var(--color-muted-foreground)] mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteId(null)} className="btn-ghost flex-1">Cancel</button>
              <button onClick={confirmDelete} className="flex-1 rounded-[0.875rem] py-3.5 font-semibold text-white" style={{ background: 'var(--color-danger)' }}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
