'use client';

import { useState, useEffect } from 'react';
import { collection, query, orderBy, onSnapshot, doc, deleteDoc } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { useAuthStore } from '@/lib/store';
import { BottomNav } from '@/components/BottomNav';
import { Search as SearchIcon, Trash2, X } from 'lucide-react';
import Image from 'next/image';

const renderWithLinks = (text: string) => {
  if (!text) return null;
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const parts = text.split(urlRegex);
  return parts.map((part, i) => part.match(urlRegex) ? (
    <a key={i} href={part} target="_blank" rel="noopener noreferrer" className="underline" style={{ color: 'var(--color-accent)' }} onClick={(e) => e.stopPropagation()}>{part}</a>
  ) : part);
};

export default function SearchPage() {
  const { user } = useAuthStore();
  const [products, setProducts] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => {
    const q = query(collection(db, 'products'), orderBy('createdAt', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const prods = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setProducts(prods);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const filteredProducts = searchQuery
    ? products.filter(p => p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.category.toLowerCase().includes(searchQuery.toLowerCase()))
    : products;

  const confirmDelete = async () => {
    if (!deleteId) return;
    try { await deleteDoc(doc(db, 'products', deleteId)); setDeleteId(null); }
    catch (error) { console.error(error); }
  };

  return (
    <div className="min-h-screen pb-32">
      <header className="px-5 pt-8 pb-4 max-w-2xl mx-auto">
        <p className="text-xs uppercase tracking-[0.2em] text-[color:var(--color-muted-foreground)] mb-1.5">Explore</p>
        <h1 className="font-display text-3xl mb-5">Find anything.</h1>
        <div className="card flex items-center gap-3 px-4 py-3">
          <SearchIcon className="w-5 h-5 text-[color:var(--color-muted-foreground)]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search products or categories..."
            className="flex-1 bg-transparent outline-none text-[color:var(--color-foreground)] placeholder:text-[color:var(--color-muted-foreground)]"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="text-[color:var(--color-muted-foreground)] hover:text-[color:var(--color-foreground)]">
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </header>

      <main className="px-5 max-w-2xl mx-auto">
        {searchQuery && (
          <p className="text-xs text-[color:var(--color-muted-foreground)] mb-4">
            {filteredProducts.length} result{filteredProducts.length !== 1 ? 's' : ''} for "{searchQuery}"
          </p>
        )}
        {loading ? (
          <div className="text-center py-12 text-[color:var(--color-muted-foreground)] text-sm">Loading...</div>
        ) : filteredProducts.length > 0 ? (
          <div className="grid grid-cols-2 gap-4">
            {filteredProducts.map(product => {
              const mediaUrl = product.mediaUrls?.[0] || product.imageUrl;
              const isVideo = mediaUrl?.match(/\.(mp4|webm|mov|m4v)(\?.*)?$/i);
              return (
                <article key={product.id} className="card p-3 flex flex-col group">
                  <div className="relative w-full aspect-square rounded-xl overflow-hidden mb-3" style={{ background: 'var(--color-muted)' }}>
                    {isVideo ? (
                      <video src={mediaUrl} className="object-cover w-full h-full" muted loop playsInline autoPlay />
                    ) : mediaUrl ? (
                      <Image src={mediaUrl} alt={product.name} fill className="object-cover transition-transform group-hover:scale-[1.03]" sizes="(max-width: 768px) 50vw, 33vw" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-xs text-[color:var(--color-muted-foreground)]">No media</div>
                    )}
                    {user?.uid === product.vendorId && (
                      <button onClick={(e) => { e.stopPropagation(); setDeleteId(product.id); }} className="absolute top-2 right-2 p-2 bg-white/95 rounded-full shadow-sm" style={{ color: 'var(--color-danger)' }}>
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                  <h3 className="font-semibold text-sm line-clamp-1">{product.name}</h3>
                  <p className="text-[11px] text-[color:var(--color-muted-foreground)] line-clamp-1 mt-0.5">by {product.vendorName}</p>
                  <p className="text-xs text-[color:var(--color-muted-foreground)] mt-1.5 line-clamp-2 break-words">{renderWithLinks(product.description)}</p>
                  <div className="mt-3 pt-3 border-t" style={{ borderColor: 'var(--color-border)' }}>
                    <span className="font-display text-lg">${product.price?.toFixed(2)}</span>
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="card p-10 text-center">
            <p className="font-display text-xl mb-1">No results</p>
            <p className="text-sm text-[color:var(--color-muted-foreground)]">Try a different search term.</p>
          </div>
        )}
      </main>

      {deleteId && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm z-50 flex items-end sm:items-center justify-center p-4">
          <div className="card p-6 max-w-sm w-full" style={{ boxShadow: 'var(--shadow-elevated)' }}>
            <h3 className="font-display text-2xl mb-1">Delete listing?</h3>
            <p className="text-sm text-[color:var(--color-muted-foreground)] mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteId(null)} className="btn-ghost flex-1">Cancel</button>
              <button onClick={confirmDelete} className="flex-1 rounded-[0.875rem] py-3.5 font-semibold text-white" style={{ background: 'var(--color-danger)' }}>Delete</button>
            </div>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
