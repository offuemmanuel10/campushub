'use client';

import { useState } from 'react';
import { auth, db, storage } from '@/lib/firebase';
import { signOut } from 'firebase/auth';
import { doc, updateDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { useAuthStore } from '@/lib/store';
import { BottomNav } from '@/components/BottomNav';
import { LogOut, BadgeCheck, Store, User as UserIcon, Edit2, X, Save, Camera, ExternalLink, Plus, Link as LinkIcon, Trash2 } from 'lucide-react';
import Image from 'next/image';

export default function ProfilePage() {
  const { profile, setProfile } = useAuthStore();
  const [requesting, setRequesting] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null);
  const [catalogFile, setCatalogFile] = useState<File | null>(null);
  const [editForm, setEditForm] = useState({
    name: '', bio: '', shopName: '', shopDescription: '', catalogUrl: '',
    contactLinks: [] as { title: string, url: string }[], specialServices: ''
  });

  const handleSignOut = async () => { await signOut(auth); };

  const handleRequestVerification = async () => {
    if (!profile) return;
    setRequesting(true);
    try {
      await updateDoc(doc(db, 'users', profile.uid), { isVerified: true });
      setProfile({ ...profile, isVerified: true });
    } catch (error) { console.error(error); }
    finally { setRequesting(false); }
  };

  const startEditing = () => {
    setEditForm({
      name: profile?.name || '', bio: profile?.bio || '',
      shopName: profile?.shopName || '', shopDescription: profile?.shopDescription || '',
      catalogUrl: profile?.catalogUrl || '', contactLinks: profile?.contactLinks || [],
      specialServices: profile?.specialServices || ''
    });
    setAvatarFile(null); setAvatarPreview(null); setCatalogFile(null);
    setIsEditing(true);
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAvatarFile(file);
      setAvatarPreview(URL.createObjectURL(file));
    }
  };

  const handleSave = async () => {
    if (!profile) return;
    setSaving(true);
    try {
      let newPhotoUrl = profile.photoUrl;
      if (avatarFile) {
        const storageRef = ref(storage, `profiles/${profile.uid}/${Date.now()}_${avatarFile.name}`);
        await uploadBytes(storageRef, avatarFile);
        newPhotoUrl = await getDownloadURL(storageRef);
      }
      const updates: any = { name: editForm.name.trim() };
      if (newPhotoUrl) updates.photoUrl = newPhotoUrl;
      if (editForm.bio.trim() !== undefined) updates.bio = editForm.bio.trim();
      if (editForm.specialServices.trim() !== undefined) updates.specialServices = editForm.specialServices.trim();
      if (profile.role === 'vendor') {
        updates.shopName = editForm.shopName.trim();
        updates.shopDescription = editForm.shopDescription.trim();
        if (catalogFile) {
          const storageRef = ref(storage, `catalogs/${profile.uid}/${Date.now()}_${catalogFile.name}`);
          await uploadBytes(storageRef, catalogFile);
          updates.catalogUrl = await getDownloadURL(storageRef);
        } else {
          let catalog = editForm.catalogUrl.trim();
          if (catalog && !catalog.startsWith('http')) catalog = 'https://' + catalog;
          updates.catalogUrl = catalog;
        }
      }
      updates.contactLinks = editForm.contactLinks
        .filter(link => link.title.trim() && link.url.trim())
        .map(link => ({
          title: link.title.trim(),
          url: link.url.trim().startsWith('http') ? link.url.trim() : 'https://' + link.url.trim()
        }));
      await updateDoc(doc(db, 'users', profile.uid), updates);
      setProfile({ ...profile, ...updates });
      setIsEditing(false);
    } catch (error) { console.error(error); }
    finally { setSaving(false); }
  };

  if (!profile) return null;

  return (
    <div className="min-h-screen pb-32">
      <header className="px-5 pt-8 pb-4 max-w-2xl mx-auto flex items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.2em] text-[color:var(--color-muted-foreground)] mb-1.5">Account</p>
          <h1 className="font-display text-3xl">Your profile.</h1>
        </div>
        {!isEditing ? (
          <button onClick={startEditing} className="size-10 rounded-full flex items-center justify-center bg-white border" style={{ borderColor: 'var(--color-border)' }} aria-label="Edit">
            <Edit2 className="w-4 h-4" />
          </button>
        ) : (
          <button onClick={() => setIsEditing(false)} className="size-10 rounded-full flex items-center justify-center bg-white border" style={{ borderColor: 'var(--color-border)' }} aria-label="Cancel">
            <X className="w-4 h-4" />
          </button>
        )}
      </header>

      <main className="px-5 max-w-2xl mx-auto space-y-5">
        {isEditing ? (
          <div className="card p-6 space-y-5">
            <h2 className="section-title text-xl">Edit profile</h2>

            <div className="flex flex-col items-center">
              <div className="relative size-24 rounded-full overflow-hidden flex items-center justify-center" style={{ background: 'var(--color-muted)' }}>
                {avatarPreview || profile.photoUrl ? (
                  <Image src={avatarPreview || profile.photoUrl || ''} alt="Profile" fill className="object-cover" />
                ) : (
                  <UserIcon className="w-9 h-9 text-[color:var(--color-primary)]" />
                )}
                <label className="absolute inset-0 bg-black/40 flex items-center justify-center cursor-pointer opacity-0 hover:opacity-100 transition">
                  <Camera className="w-5 h-5 text-white" />
                  <input type="file" accept="image/*" className="sr-only" onChange={handleAvatarChange} />
                </label>
              </div>
              <p className="text-xs text-[color:var(--color-muted-foreground)] mt-2">Tap to change photo</p>
            </div>

            <div>
              <label className="label">Full Name</label>
              <input type="text" value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} className="input-field" />
            </div>
            <div>
              <label className="label">Bio</label>
              <textarea value={editForm.bio} onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })} className="input-field resize-none h-20" />
            </div>
            <div>
              <label className="label">Special Services / Skills</label>
              <textarea value={editForm.specialServices} onChange={(e) => setEditForm({ ...editForm, specialServices: e.target.value })} className="input-field resize-none h-20" placeholder="E.g. Graphic Design, Tutoring..." />
            </div>

            {profile.role === 'vendor' && (
              <>
                <div>
                  <label className="label">Shop Name</label>
                  <input type="text" value={editForm.shopName} onChange={(e) => setEditForm({ ...editForm, shopName: e.target.value })} className="input-field" />
                </div>
                <div>
                  <label className="label">Shop Description</label>
                  <textarea value={editForm.shopDescription} onChange={(e) => setEditForm({ ...editForm, shopDescription: e.target.value })} className="input-field resize-none h-20" />
                </div>
                <div>
                  <label className="label">Catalog URL</label>
                  <input type="url" value={editForm.catalogUrl} onChange={(e) => setEditForm({ ...editForm, catalogUrl: e.target.value })} placeholder="https://..." className="input-field" disabled={!!catalogFile} />
                  <label className="mt-2 flex items-center justify-center w-full h-14 border-2 border-dashed rounded-xl cursor-pointer text-sm" style={{ borderColor: 'var(--color-border)', background: 'var(--color-muted)' }}>
                    <span className="font-medium">{catalogFile ? catalogFile.name : 'Or upload catalog file (PDF/Image)'}</span>
                    <input type="file" className="hidden" accept="image/*,application/pdf" onChange={(e) => setCatalogFile(e.target.files?.[0] || null)} />
                  </label>
                </div>
              </>
            )}

            <div>
              <label className="label">Contact Links</label>
              {editForm.contactLinks.map((link, index) => (
                <div key={index} className="flex gap-2 mb-2">
                  <input type="text" placeholder="Title" value={link.title}
                    onChange={(e) => { const n = [...editForm.contactLinks]; n[index].title = e.target.value; setEditForm({ ...editForm, contactLinks: n }); }}
                    className="input-field flex-1 text-sm" />
                  <input type="text" placeholder="URL" value={link.url}
                    onChange={(e) => { const n = [...editForm.contactLinks]; n[index].url = e.target.value; setEditForm({ ...editForm, contactLinks: n }); }}
                    className="input-field flex-1 text-sm" />
                  <button onClick={() => setEditForm({ ...editForm, contactLinks: editForm.contactLinks.filter((_, i) => i !== index) })}
                    className="size-10 rounded-xl flex items-center justify-center" style={{ color: 'var(--color-danger)', background: 'var(--color-danger-soft)' }}>
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
              <button type="button" onClick={() => setEditForm({ ...editForm, contactLinks: [...editForm.contactLinks, { title: '', url: '' }] })}
                className="text-sm font-semibold flex items-center gap-1 mt-2" style={{ color: 'var(--color-accent)' }}>
                <Plus className="w-4 h-4" /> Add link
              </button>
            </div>

            <button onClick={handleSave} disabled={saving} className="btn-primary w-full">
              <Save className="w-4 h-4" />{saving ? 'Saving...' : 'Save changes'}
            </button>
          </div>
        ) : (
          <>
            <div className="card overflow-hidden">
              <div className="h-24 relative" style={{ background: 'linear-gradient(135deg, var(--color-primary), #2a3a66)' }}>
                <div className="absolute -right-6 -top-6 size-28 rounded-full opacity-30" style={{ background: 'var(--color-accent)' }} />
              </div>
              <div className="px-6 pb-6 -mt-12">
                <div className="size-24 rounded-full overflow-hidden flex items-center justify-center bg-white border-4" style={{ borderColor: 'var(--color-surface)' }}>
                  <div className="size-full flex items-center justify-center" style={{ background: 'var(--color-muted)' }}>
                    {profile.photoUrl ? (
                      <Image src={profile.photoUrl} alt="Profile" width={96} height={96} className="object-cover w-full h-full" />
                    ) : (
                      <UserIcon className="w-9 h-9 text-[color:var(--color-primary)]" />
                    )}
                  </div>
                </div>
                <div className="mt-4 flex items-center gap-2">
                  <h2 className="font-display text-2xl">{profile.name}</h2>
                  {profile.isVerified && <BadgeCheck className="w-5 h-5" style={{ color: 'var(--color-accent)' }} />}
                </div>
                <p className="text-sm text-[color:var(--color-muted-foreground)]">{profile.email}</p>
                <div className="flex items-center gap-2 mt-3">
                  <span className="pill capitalize">
                    {profile.role === 'vendor' ? <Store className="w-3.5 h-3.5" /> : <UserIcon className="w-3.5 h-3.5" />}
                    {profile.role}
                  </span>
                  {profile.isVerified && (
                    <span className="pill" style={{ background: 'var(--color-accent-soft)', color: 'var(--color-accent)' }}>
                      <BadgeCheck className="w-3.5 h-3.5" /> Verified
                    </span>
                  )}
                </div>
                {profile.bio && <p className="text-sm mt-4 leading-relaxed text-[color:var(--color-foreground)]">{profile.bio}</p>}
                {profile.specialServices && (
                  <div className="mt-4 p-4 rounded-2xl" style={{ background: 'var(--color-muted)' }}>
                    <p className="text-[10px] uppercase tracking-[0.18em] font-semibold text-[color:var(--color-muted-foreground)] mb-1">Special services</p>
                    <p className="text-sm">{profile.specialServices}</p>
                  </div>
                )}
              </div>
            </div>

            {profile.role === 'vendor' && (
              <div className="card p-6">
                <h3 className="section-title text-lg mb-4">Shop details</h3>
                <div className="space-y-3">
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.18em] font-semibold text-[color:var(--color-muted-foreground)]">Shop name</p>
                    <p className="font-medium mt-0.5">{profile.shopName}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-[0.18em] font-semibold text-[color:var(--color-muted-foreground)]">Description</p>
                    <p className="text-sm mt-0.5">{profile.shopDescription}</p>
                  </div>
                </div>
                <div className="mt-5 pt-5 border-t" style={{ borderColor: 'var(--color-border)' }}>
                  <p className="text-[10px] uppercase tracking-[0.18em] font-semibold text-[color:var(--color-muted-foreground)] mb-2">Catalog</p>
                  {profile.catalogUrl ? (
                    <a href={profile.catalogUrl} target="_blank" rel="noopener noreferrer" className="font-semibold flex items-center gap-1.5" style={{ color: 'var(--color-accent)' }}>
                      View Catalog <ExternalLink className="w-4 h-4" />
                    </a>
                  ) : (
                    <button onClick={startEditing} className="text-sm flex items-center gap-1 text-[color:var(--color-muted-foreground)] hover:text-[color:var(--color-foreground)]">
                      No catalog. Tap to add <Plus className="w-4 h-4" />
                    </button>
                  )}
                </div>
                {!profile.isVerified && (
                  <button onClick={handleRequestVerification} disabled={requesting}
                    className="w-full mt-5 py-3 rounded-[0.875rem] font-semibold transition-all"
                    style={{ background: 'var(--color-accent-soft)', color: 'var(--color-accent)' }}>
                    {requesting ? 'Requesting...' : 'Request verification'}
                  </button>
                )}
              </div>
            )}

            <div className="card p-6">
              <h3 className="section-title text-lg mb-4">Contact links</h3>
              {profile.contactLinks && profile.contactLinks.length > 0 ? (
                <div className="space-y-2">
                  {profile.contactLinks.map((link, i) => (
                    <a key={i} href={link.url} target="_blank" rel="noopener noreferrer"
                      className="flex items-center gap-3 p-3 rounded-xl transition-all hover:bg-[color:var(--color-muted)]">
                      <div className="size-9 rounded-xl flex items-center justify-center" style={{ background: 'var(--color-muted)' }}>
                        <LinkIcon className="w-4 h-4" />
                      </div>
                      <span className="font-medium text-sm flex-1">{link.title}</span>
                      <ExternalLink className="w-4 h-4 text-[color:var(--color-muted-foreground)]" />
                    </a>
                  ))}
                </div>
              ) : (
                <button onClick={startEditing} className="text-sm flex items-center gap-1 text-[color:var(--color-muted-foreground)] hover:text-[color:var(--color-foreground)]">
                  No contact links. Tap to add <Plus className="w-4 h-4" />
                </button>
              )}
            </div>
          </>
        )}

        <button onClick={handleSignOut}
          className="w-full py-4 rounded-2xl font-semibold flex items-center justify-center gap-2 bg-white border transition-all hover:bg-[color:var(--color-danger-soft)]"
          style={{ borderColor: 'var(--color-border)', color: 'var(--color-danger)' }}>
          <LogOut className="w-4 h-4" /> Sign Out
        </button>
      </main>

      <BottomNav />
    </div>
  );
}
