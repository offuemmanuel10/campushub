'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { db, storage } from '@/lib/firebase';
import { useAuthStore } from '@/lib/store';
import { ArrowLeft, Upload, X, Image as ImageIcon } from 'lucide-react';
import Link from 'next/link';

const CATEGORIES = ['Housing', 'Events', 'Electronics', 'Clothing', 'Services', 'Other'];

export default function CreateListing() {
  const router = useRouter();
  const { user, profile } = useAuthStore();
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [files, setFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="size-8 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--color-muted)', borderTopColor: 'var(--color-primary)' }} />
      </div>
    );
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setFiles(prev => [...prev, ...newFiles].slice(0, 5));
    }
  };

  const removeFile = (index: number) => setFiles(prev => prev.filter((_, i) => i !== index));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    setError('');
    try {
      const mediaUrls: string[] = [];
      if (files.length > 0) {
        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          const storageRef = ref(storage, `products/${user.uid}/${Date.now()}_${file.name}`);
          await uploadBytes(storageRef, file);
          const url = await getDownloadURL(storageRef);
          mediaUrls.push(url);
        }
      }
      const productData = {
        vendorId: user.uid,
        vendorName: profile.shopName || profile.name,
        name, description,
        price: parseFloat(price),
        category, mediaUrls,
        createdAt: serverTimestamp(),
      };
      await addDoc(collection(db, 'products'), productData);
      router.push('/');
    } catch (err: any) { setError(err.message); }
    finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen pb-32">
      <header className="px-5 py-4 sticky top-0 z-40 backdrop-blur" style={{ background: 'rgba(250,250,247,0.85)', borderBottom: '1px solid var(--color-border)' }}>
        <div className="max-w-2xl mx-auto flex items-center gap-4">
          <Link href="/" className="size-10 rounded-full flex items-center justify-center hover:bg-[color:var(--color-muted)]">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div>
            <p className="text-xs uppercase tracking-[0.2em] text-[color:var(--color-muted-foreground)]">New listing</p>
            <h1 className="font-display text-xl">Create a listing</h1>
          </div>
        </div>
      </header>

      <main className="px-5 py-6 max-w-2xl mx-auto">
        {error && (
          <div className="rounded-xl px-4 py-3 text-sm mb-6" style={{ background: 'var(--color-danger-soft)', color: 'var(--color-danger)' }}>{error}</div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="card p-5 space-y-5">
            <div>
              <label className="label">Product name</label>
              <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="input-field" required placeholder="What are you selling?" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="label">Price</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[color:var(--color-muted-foreground)]">$</span>
                  <input type="number" step="0.01" min="0" value={price} onChange={(e) => setPrice(e.target.value)} className="input-field pl-8" required placeholder="0.00" />
                </div>
              </div>
              <div>
                <label className="label">Category</label>
                <select value={category} onChange={(e) => setCategory(e.target.value)} className="input-field bg-white">
                  {CATEGORIES.map(cat => <option key={cat} value={cat}>{cat}</option>)}
                </select>
              </div>
            </div>

            <div>
              <label className="label">Description</label>
              <textarea value={description} onChange={(e) => setDescription(e.target.value)} className="input-field resize-none h-32" required placeholder="Tell buyers about it..." />
            </div>
          </div>

          <div className="card p-5">
            <label className="label">Media</label>
            <label className="block w-full cursor-pointer rounded-2xl border-2 border-dashed py-10 px-6 text-center transition-all hover:border-[color:var(--color-primary)] hover:bg-[color:var(--color-muted)]" style={{ borderColor: 'var(--color-border)' }}>
              <div className="size-12 mx-auto mb-3 rounded-2xl flex items-center justify-center" style={{ background: 'var(--color-muted)' }}>
                <Upload className="w-5 h-5" style={{ color: 'var(--color-primary)' }} />
              </div>
              <p className="font-medium text-sm mb-1">Drop photos or videos here</p>
              <p className="text-xs text-[color:var(--color-muted-foreground)]">PNG, JPG, MP4 — up to 5 files, 10MB each</p>
              <input type="file" multiple accept="image/*,video/*" className="sr-only" onChange={handleFileChange} />
            </label>

            {files.length > 0 && (
              <div className="mt-4 grid grid-cols-5 gap-2">
                {files.map((file, index) => (
                  <div key={index} className="relative aspect-square rounded-xl overflow-hidden" style={{ background: 'var(--color-muted)' }}>
                    {file.type.startsWith('video/') ? (
                      <video src={URL.createObjectURL(file)} className="w-full h-full object-cover" />
                    ) : (
                      <img src={URL.createObjectURL(file)} alt="preview" className="w-full h-full object-cover" />
                    )}
                    <button type="button" onClick={() => removeFile(index)} className="absolute top-1 right-1 bg-black/60 text-white rounded-full p-1 hover:bg-black/80">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <button type="submit" disabled={loading} className="btn-primary w-full">
            {loading ? 'Publishing...' : 'Publish listing'}
          </button>
        </form>
      </main>
    </div>
  );
}
