'use client';

import { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { BottomNav } from '@/components/BottomNav';
import Image from 'next/image';
import { BadgeCheck, ExternalLink, User as UserIcon, Store } from 'lucide-react';

export default function BrandsPage() {
  const [verifiedUsers, setVerifiedUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(collection(db, 'users'), where('isVerified', '==', true));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const users = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
        .filter((u: any) => u.specialServices && u.specialServices.trim().length > 0);
      setVerifiedUsers(users);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  return (
    <div className="min-h-screen pb-32">
      <header className="px-5 pt-8 pb-4 max-w-2xl mx-auto">
        <span className="pill mb-3"><BadgeCheck className="w-3.5 h-3.5" style={{ color: 'var(--color-accent)' }} />Verified</span>
        <h1 className="font-display text-3xl mb-1">Brands & services.</h1>
        <p className="text-[color:var(--color-muted-foreground)]">Verified student creators offering unique skills and shops.</p>
      </header>

      <main className="px-5 max-w-2xl mx-auto">
        {loading ? (
          <div className="flex justify-center items-center h-40">
            <div className="size-8 border-4 rounded-full animate-spin" style={{ borderColor: 'var(--color-muted)', borderTopColor: 'var(--color-primary)' }} />
          </div>
        ) : verifiedUsers.length === 0 ? (
          <div className="card p-10 text-center">
            <BadgeCheck className="w-10 h-10 mx-auto mb-4 text-[color:var(--color-muted-foreground)] opacity-40" />
            <h2 className="font-display text-xl mb-1">No verified brands yet</h2>
            <p className="text-sm text-[color:var(--color-muted-foreground)]">Check back soon as student vendors get verified.</p>
          </div>
        ) : (
          <div className="grid gap-5 md:grid-cols-2">
            {verifiedUsers.map((user) => (
              <article key={user.id} className="card p-6 flex flex-col">
                <div className="flex items-center gap-4 mb-5">
                  <div className="relative size-16 rounded-2xl overflow-hidden flex items-center justify-center shrink-0" style={{ background: 'var(--color-muted)' }}>
                    {user.photoUrl ? (
                      <Image src={user.photoUrl} alt={user.name} fill className="object-cover" />
                    ) : (
                      <UserIcon className="w-7 h-7 text-[color:var(--color-primary)]" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <h2 className="font-display text-lg flex items-center gap-1.5 truncate">
                      {user.name}
                      <BadgeCheck className="w-4 h-4 shrink-0" style={{ color: 'var(--color-accent)' }} />
                    </h2>
                    {user.shopName && (
                      <div className="flex items-center gap-1 text-sm text-[color:var(--color-muted-foreground)]">
                        <Store className="w-3 h-3" />
                        <span className="truncate">{user.shopName}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex-1 mb-4">
                  <p className="text-[10px] uppercase tracking-[0.18em] font-semibold text-[color:var(--color-muted-foreground)] mb-2">Services & skills</p>
                  <p className="text-sm whitespace-pre-wrap text-[color:var(--color-foreground)] leading-relaxed">
                    {user.specialServices}
                  </p>
                </div>

                {user.catalogUrl && (
                  <a href={user.catalogUrl} target="_blank" rel="noopener noreferrer" className="mt-auto inline-flex items-center justify-center gap-2 py-3 rounded-[0.875rem] font-semibold text-sm" style={{ background: 'var(--color-muted)', color: 'var(--color-foreground)' }}>
                    View Catalog <ExternalLink className="w-4 h-4" />
                  </a>
                )}
              </article>
            ))}
          </div>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
